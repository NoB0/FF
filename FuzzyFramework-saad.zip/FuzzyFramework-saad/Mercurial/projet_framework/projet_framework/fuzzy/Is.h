#ifndef IS_H
#define IS_H

namespace fuzzy {
	template <class T>
	class Is : public interpret::UnaryExpression<T> {
	};
}
#endif // !IS_H
