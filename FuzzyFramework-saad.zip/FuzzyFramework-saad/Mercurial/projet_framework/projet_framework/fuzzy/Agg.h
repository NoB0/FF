#ifndef AGG_H
#define AGG_H

namespace fuzzy {
	template <class T>
	class Agg : public interpret::BinaryExpression<T> {
	};
}

#endif // !AGG_H

