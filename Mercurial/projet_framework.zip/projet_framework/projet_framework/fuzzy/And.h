#ifndef AND_H
#define AND_H

namespace fuzzy {
	template <class T>
	class And : public interpret::BinaryExpression<T> {
	};
}

#endif
