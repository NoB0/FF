#ifndef NOT_H
#define NOT_H

namespace fuzzy {
	template <class T>
	class Not : public interpret::UnaryExpression<T> {
	};
}
#endif // !NOT_H

